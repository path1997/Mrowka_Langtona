#include "Komorka.h"



Komorka::Komorka()
{
	stan = false;
}

Komorka::~Komorka()
{
}