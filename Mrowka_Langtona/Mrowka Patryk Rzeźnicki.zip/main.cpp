#include"GraKonsola.h"

int main() {
	GraKonsola K(50, 120,2);
	K.start(0);
	return 0;
}